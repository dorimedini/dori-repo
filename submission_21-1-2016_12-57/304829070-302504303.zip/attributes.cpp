#include "attributes.h"
bool g_is_last_type_declaration_matrix = false;